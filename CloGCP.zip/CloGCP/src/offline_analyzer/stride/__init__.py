"""stride boundary; see ARCHITECTURE.md for implemented scope."""
